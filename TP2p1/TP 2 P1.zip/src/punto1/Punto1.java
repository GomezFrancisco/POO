package punto1;

import java.util.Scanner;

public class Punto1 {

	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in); //para leer desde el teclado
		String texto = in.nextLine();
		// usando la clase Scanner

		System.out.println("Se ingreso: " + texto);
	} 

}
